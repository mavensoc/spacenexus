const express = require('express');
const router = express.Router();
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const dynamoDB = new AWS.DynamoDB.DocumentClient();
const tableName = process.env.DYNAMODB_TABLE_NAME;

// Get all tasks
router.get('/', async (req, res) => {
  const params = {
    TableName: tableName,
    IndexName: 'GSI1',
    KeyConditionExpression: 'GSI1PK = :pk',
    ExpressionAttributeValues: {
      ':pk': 'TASK'
    }
  };

  try {
    const result = await dynamoDB.query(params).promise();
    res.json(result.Items);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching tasks' });
  }
});

// Create a new task
router.post('/', async (req, res) => {
  const { text, assignedTo } = req.body;
  const id = uuidv4();
  const timestamp = new Date().toISOString();

  const params = {
    TableName: tableName,
    Item: {
      PK: `TASK#${id}`,
      SK: `METADATA#${id}`,
      GSI1PK: 'TASK',
      GSI1SK: timestamp,
      id,
      text,
      assignedTo,
      completed: false,
      createdAt: timestamp,
      updatedAt: timestamp
    }
  };

  try {
    await dynamoDB.put(params).promise();
    res.status(201).json(params.Item);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error creating task' });
  }
});

// Update a task
router.patch('/:id', async (req, res) => {
  const { id } = req.params;
  const { text, completed, assignedTo } = req.body;
  const timestamp = new Date().toISOString();

  const params = {
    TableName: tableName,
    Key: {
      PK: `TASK#${id}`,
      SK: `METADATA#${id}`
    },
    UpdateExpression: 'set #text = :text, completed = :completed, assignedTo = :assignedTo, updatedAt = :updatedAt',
    ExpressionAttributeNames: {
      '#text': 'text'
    },
    ExpressionAttributeValues: {
      ':text': text,
      ':completed': completed,
      ':assignedTo': assignedTo,
      ':updatedAt': timestamp
    },
    ReturnValues: 'ALL_NEW'
  };

  try {
    const result = await dynamoDB.update(params).promise();
    res.json(result.Attributes);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating task' });
  }
});

module.exports = router;

