const express = require('express');
const router = express.Router();
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const dynamoDB = new AWS.DynamoDB.DocumentClient();
const tableName = process.env.DYNAMODB_TABLE_NAME;

// Get all documents
router.get('/', async (req, res) => {
  const params = {
    TableName: tableName,
    IndexName: 'GSI1',
    KeyConditionExpression: 'GSI1PK = :pk',
    ExpressionAttributeValues: {
      ':pk': 'DOCUMENT'
    }
  };

  try {
    const result = await dynamoDB.query(params).promise();
    res.json(result.Items);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching documents' });
  }
});

// Create a new document
router.post('/', async (req, res) => {
  const { title, content } = req.body;
  const id = uuidv4();
  const timestamp = new Date().toISOString();

  const params = {
    TableName: tableName,
    Item: {
      PK: `DOCUMENT#${id}`,
      SK: `METADATA#${id}`,
      GSI1PK: 'DOCUMENT',
      GSI1SK: timestamp,
      id,
      title,
      content,
      createdAt: timestamp,
      updatedAt: timestamp
    }
  };

  try {
    await dynamoDB.put(params).promise();
    res.status(201).json(params.Item);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error creating document' });
  }
});

// Update a document
router.patch('/:id', async (req, res) => {
  const { id } = req.params;
  const { title, content } = req.body;
  const timestamp = new Date().toISOString();

  const params = {
    TableName: tableName,
    Key: {
      PK: `DOCUMENT#${id}`,
      SK: `METADATA#${id}`
    },
    UpdateExpression: 'set title = :title, content = :content, updatedAt = :updatedAt',
    ExpressionAttributeValues: {
      ':title': title,
      ':content': content,
      ':updatedAt': timestamp
    },
    ReturnValues: 'ALL_NEW'
  };

  try {
    const result = await dynamoDB.update(params).promise();
    res.json(result.Attributes);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating document' });
  }
});

module.exports = router;

