import dynamic from 'next/dynamic'
import { Suspense, lazy } from 'react'
import { ModeToggle } from './components/mode-toggle'
import { Navigation } from './components/Navigation'

const Workspace = dynamic(() => import('./components/Workspace').then(mod => mod.Workspace), { ssr: false })
const VideoChat = dynamic(() => import('./components/VideoChat').then(mod => mod.VideoChat), { ssr: false })
const CodeGenerator = dynamic(() => import('./components/CodeGenerator').then(mod => mod.CodeGenerator), { ssr: false })
const DataVisualization = dynamic(() => import('./components/DataVisualization').then(mod => mod.DataVisualization), { ssr: false })
const SharedDocument = dynamic(() => import('./components/SharedDocument').then(mod => mod.SharedDocument), { ssr: false })
const Whiteboard = dynamic(() => import('./components/Whiteboard').then(mod => mod.Whiteboard), { ssr: false })
const TaskManager = dynamic(() => import('./components/TaskManager').then(mod => mod.TaskManager), { ssr: false })

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-4 sm:p-6 bg-background text-foreground">
      <div className="w-full max-w-7xl">
        <div className="flex justify-between items-center mb-6 sm:mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold">NexusSpace</h1>
          <div className="flex items-center space-x-4">
            <Navigation />
            <ModeToggle />
          </div>
        </div>
        <div className="grid grid-cols-1 gap-4">
          <Suspense fallback={<div>Loading shared document...</div>}>
            <SharedDocument />
          </Suspense>
          <Suspense fallback={<div>Loading workspace...</div>}>
            <Workspace />
          </Suspense>
          <Suspense fallback={<div>Loading whiteboard...</div>}>
            <Whiteboard />
          </Suspense>
          <Suspense fallback={<div>Loading task manager...</div>}>
            <TaskManager />
          </Suspense>
          <Suspense fallback={<div>Loading video chat...</div>}>
            <VideoChat />
          </Suspense>
          <Suspense fallback={<div>Loading code generator...</div>}>
            <CodeGenerator />
          </Suspense>
          <Suspense fallback={<div>Loading data visualization...</div>}>
            <DataVisualization />
          </Suspense>
        </div>
      </div>
    </main>
  )
}

