'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import io from 'socket.io-client'

const socket = io('http://localhost:5000');

export function SharedDocument() {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [documentId, setDocumentId] = useState<string | null>(null)

  useEffect(() => {
    // Fetch the most recent document or create a new one
    fetch('http://localhost:5000/api/documents')
      .then(response => response.json())
      .then(documents => {
        if (documents.length > 0) {
          const latestDocument = documents[0];
          setTitle(latestDocument.title);
          setContent(latestDocument.content);
          setDocumentId(latestDocument._id);
        } else {
          createNewDocument();
        }
      });

    // Listen for updates from other users
    socket.on('documentUpdate', (updatedDocument) => {
      if (updatedDocument._id === documentId) {
        setTitle(updatedDocument.title);
        setContent(updatedDocument.content);
      }
    });

    return () => {
      socket.off('documentUpdate');
    };
  }, [documentId]);

  const createNewDocument = () => {
    fetch('http://localhost:5000/api/documents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Untitled Document', content: '' })
    })
      .then(response => response.json())
      .then(newDocument => {
        setTitle(newDocument.title);
        setContent(newDocument.content);
        setDocumentId(newDocument._id);
      });
  };

  const updateDocument = () => {
    if (!documentId) return;

    fetch(`http://localhost:5000/api/documents/${documentId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, content })
    })
      .then(response => response.json())
      .then(updatedDocument => {
        socket.emit('documentUpdate', updatedDocument);
      });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl sm:text-2xl">Shared Document</CardTitle>
      </CardHeader>
      <CardContent>
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Document Title"
          className="mb-2"
        />
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Start typing to collaborate..."
          className="min-h-[150px] sm:min-h-[200px] mb-2"
        />
        <Button onClick={updateDocument}>Save Changes</Button>
      </CardContent>
    </Card>
  )
}

