'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import io from 'socket.io-client'

const socket = io('http://localhost:5000');

interface Task {
  _id: string
  text: string
  completed: boolean
  assignedTo: string
}

export function TaskManager() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTask, setNewTask] = useState('')
  const [assignTo, setAssignTo] = useState('')

  useEffect(() => {
    fetchTasks();

    socket.on('taskUpdate', (updatedTask) => {
      setTasks(prevTasks => prevTasks.map(task => 
        task._id === updatedTask._id ? updatedTask : task
      ));
    });

    return () => {
      socket.off('taskUpdate');
    };
  }, []);

  const fetchTasks = () => {
    fetch('http://localhost:5000/api/tasks')
      .then(response => response.json())
      .then(setTasks);
  };

  const addTask = () => {
    if (newTask.trim() !== '' && assignTo.trim() !== '') {
      fetch('http://localhost:5000/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: newTask, assignedTo: assignTo })
      })
        .then(response => response.json())
        .then(newTask => {
          setTasks([...tasks, newTask]);
          setNewTask('');
          setAssignTo('');
          socket.emit('taskUpdate', newTask);
        });
    }
  };

  const toggleTask = (id: string) => {
    const taskToUpdate = tasks.find(task => task._id === id);
    if (!taskToUpdate) return;

    fetch(`http://localhost:5000/api/tasks/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ completed: !taskToUpdate.completed })
    })
      .then(response => response.json())
      .then(updatedTask => {
        setTasks(tasks.map(task => 
          task._id === id ? updatedTask : task
        ));
        socket.emit('taskUpdate', updatedTask);
      });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl sm:text-2xl">Task Manager</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 mb-4">
          <Input
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="New task..."
            className="flex-grow"
          />
          <Input
            value={assignTo}
            onChange={(e) => setAssignTo(e.target.value)}
            placeholder="Assign to..."
            className="flex-grow"
          />
          <Button onClick={addTask} className="w-full sm:w-auto">Add Task</Button>
        </div>
        <ul className="space-y-2">
          {tasks.map(task => (
            <li key={task._id} className="flex items-center space-x-2">
              <Checkbox
                id={`task-${task._id}`}
                checked={task.completed}
                onCheckedChange={() => toggleTask(task._id)}
              />
              <label
                htmlFor={`task-${task._id}`}
                className={`flex-grow ${task.completed ? 'line-through text-gray-500' : ''}`}
              >
                {task.text}
              </label>
              <span className="text-sm text-gray-500">({task.assignedTo})</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

