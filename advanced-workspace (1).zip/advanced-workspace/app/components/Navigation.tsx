'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from 'lucide-react'

export function Navigation() {
  const [open, setOpen] = useState(false)

  const navItems = [
    { name: 'Shared Document', href: '#shared-document' },
    { name: 'Workspace', href: '#workspace' },
    { name: 'Whiteboard', href: '#whiteboard' },
    { name: 'Task Manager', href: '#task-manager' },
    { name: 'Video Chat', href: '#video-chat' },
    { name: 'Code Generator', href: '#code-generator' },
    { name: 'Data Visualization', href: '#data-visualization' },
  ]

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="md:hidden">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Toggle navigation menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left">
        <nav>
          <ul className="space-y-4">
            {navItems.map((item) => (
              <li key={item.name}>
                <a
                  href={item.href}
                  className="text-lg hover:underline"
                  onClick={() => setOpen(false)}
                >
                  {item.name}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </SheetContent>
    </Sheet>
  )
}

