'use client'

import { useState } from 'react'
import { useCompletion } from 'ai/react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function CodeGenerator() {
  const [language, setLanguage] = useState('javascript')
  const [exampleOutput, setExampleOutput] = useState(`function fibonacci(n) {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

console.log(fibonacci(10)); // Output: 55`)
  const { completion, input, handleInputChange, handleSubmit } = useCompletion({
    api: '/api/generate-code',
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl sm:text-2xl">AI Code Generator</CardTitle>
      </CardHeader>
      <CardContent>
        <Select 
          value={language} 
          onValueChange={(value) => {
            setLanguage(value);
            switch(value) {
              case 'javascript':
                setExampleOutput(`function fibonacci(n) {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

console.log(fibonacci(10)); // Output: 55`);
                break;
              case 'python':
                setExampleOutput(`def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

print(fibonacci(10))  # Output: 55`);
                break;
              case 'rust':
                setExampleOutput(`fn fibonacci(n: u32) -> u32 {
    match n {
        0 => 0,
        1 => 1,
        _ => fibonacci(n - 1) + fibonacci(n - 2),
    }
}

fn main() {
    println!("{}", fibonacci(10)); // Output: 55
}`);
                break;
            }
          }}
        >
          <SelectTrigger className="mb-2 w-full sm:w-auto">
            <SelectValue placeholder="Select language" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="javascript">JavaScript</SelectItem>
            <SelectItem value="python">Python</SelectItem>
            <SelectItem value="rust">Rust</SelectItem>
          </SelectContent>
        </Select>
        <form onSubmit={handleSubmit} className="space-y-2">
          <Input
            value={input}
            onChange={handleInputChange}
            placeholder="Describe the code you want..."
          />
          <Button type="submit" className="w-full sm:w-auto">Generate</Button>
        </form>
        {completion ? (
          <pre className="mt-4 p-2 bg-muted rounded overflow-x-auto text-sm">
            <code>{completion}</code>
          </pre>
        ) : (
          <div className="mt-4">
            <h4 className="text-sm font-semibold mb-2">Example Output:</h4>
            <pre className="p-2 bg-muted rounded overflow-x-auto text-sm">
              <code>{exampleOutput}</code>
            </pre>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

