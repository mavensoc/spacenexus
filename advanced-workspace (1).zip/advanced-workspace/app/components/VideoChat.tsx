'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function VideoChat() {
  const [isChatting, setIsChatting] = useState(false)

  const startChat = () => {
    setIsChatting(true)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl sm:text-2xl">Video Chat</CardTitle>
      </CardHeader>
      <CardContent>
        {isChatting ? (
          <div className="bg-secondary h-40 sm:h-60 flex items-center justify-center rounded">
            Video chat in progress...
          </div>
        ) : (
          <Button onClick={startChat} className="w-full sm:w-auto">
            Start Video Chat
          </Button>
        )}
      </CardContent>
    </Card>
  )
}

