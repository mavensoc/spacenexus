'use client'

import { useState, useEffect } from 'react'
import { useChat } from 'ai/react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

export function Workspace() {
  const [collaborators, setCollaborators] = useState([])
  const { messages, input, handleInputChange, handleSubmit } = useChat()

  useEffect(() => {
    const interval = setInterval(() => {
      setCollaborators(prev => [...prev, { id: Date.now(), name: `User ${prev.length + 1}` }])
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Workspace</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <h3 className="text-lg font-semibold mb-2">Collaborators</h3>
          <ul>
            {collaborators.map(user => (
              <li key={user.id}>{user.name}</li>
            ))}
          </ul>
        </div>
        <ScrollArea className="h-[300px] mb-4">
          {messages.map(m => (
            <div key={m.id} className={`mb-2 ${m.role === 'user' ? 'text-blue-600 dark:text-blue-400' : 'text-green-600 dark:text-green-400'}`}>
              <strong>{m.role === 'user' ? 'You:' : 'AI:'}</strong> {m.content}
            </div>
          ))}
        </ScrollArea>
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            value={input}
            onChange={handleInputChange}
            placeholder="Ask AI for assistance..."
          />
          <Button type="submit">Send</Button>
        </form>
      </CardContent>
    </Card>
  )
}

