'use client'

import { useEffect, useRef } from 'react'
import * as d3 from 'd3'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const data = [
  { name: 'A', value: 20 },
  { name: 'B', value: 50 },
  { name: 'C', value: 30 },
  { name: 'D', value: 40 },
  { name: 'E', value: 60 },
]

export function DataVisualization() {
  const svgRef = useRef<SVGSVGElement>(null)

  useEffect(() => {
    if (!svgRef.current) return

    const svg = d3.select(svgRef.current)
    const width = svg.node()?.getBoundingClientRect().width || 300
    const height = 300
    const margin = { top: 20, right: 20, bottom: 30, left: 40 }

    const x = d3
      .scaleBand()
      .range([margin.left, width - margin.right])
      .domain(data.map((d) => d.name))
      .padding(0.1)

    const y = d3
      .scaleLinear()
      .range([height - margin.bottom, margin.top])
      .domain([0, d3.max(data, (d) => d.value) || 0])

    svg.selectAll('*').remove()

    svg
      .append('g')
      .attr('fill', 'var(--primary)')
      .selectAll('rect')
      .data(data)
      .join('rect')
      .attr('x', (d) => x(d.name) || 0)
      .attr('y', (d) => y(d.value))
      .attr('height', (d) => y(0) - y(d.value))
      .attr('width', x.bandwidth())

    svg
      .append('g')
      .attr('transform', `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(x))

    svg
      .append('g')
      .attr('transform', `translate(${margin.left},0)`)
      .call(d3.axisLeft(y))

  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl sm:text-2xl">Real-time Data Visualization</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="w-full overflow-x-auto">
          <svg ref={svgRef} width="100%" height={300}></svg>
        </div>
      </CardContent>
    </Card>
  )
}

