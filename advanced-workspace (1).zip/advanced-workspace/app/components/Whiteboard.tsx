'use client'

import { useRef, useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function Whiteboard() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [scale, setScale] = useState(1)
  const [offset, setOffset] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const context = canvas.getContext('2d')
    if (!context) return

    const startDrawing = (e: TouchEvent | MouseEvent) => {
      setIsDrawing(true)
      draw(e)
    }

    const stopDrawing = () => setIsDrawing(false)

    const draw = (e: TouchEvent | MouseEvent) => {
      if (!isDrawing) return
      const rect = canvas.getBoundingClientRect()
      let x, y
      if (e instanceof TouchEvent) {
        x = (e.touches[0].clientX - rect.left - offset.x) / scale
        y = (e.touches[0].clientY - rect.top - offset.y) / scale
      } else {
        x = (e.clientX - rect.left - offset.x) / scale
        y = (e.clientY - rect.top - offset.y) / scale
      }
      context.lineTo(x, y)
      context.stroke()
      context.beginPath()
      context.moveTo(x, y)
    }

    const handleZoom = (e: WheelEvent) => {
      e.preventDefault()
      const delta = e.deltaY
      setScale(prevScale => Math.max(0.1, Math.min(5, prevScale - delta / 500)))
    }

    const handlePan = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        e.preventDefault()
        const touch1 = e.touches[0]
        const touch2 = e.touches[1]
        const dist = Math.hypot(touch1.clientX - touch2.clientX, touch1.clientY - touch2.clientY)
        setScale(prevScale => Math.max(0.1, Math.min(5, prevScale * (1 + (dist - prevDist) / 200))))
        prevDist = dist
      }
    }

    let prevDist = 0

    canvas.addEventListener('mousedown', startDrawing)
    canvas.addEventListener('mousemove', draw)
    canvas.addEventListener('mouseup', stopDrawing)
    canvas.addEventListener('mouseout', stopDrawing)
    canvas.addEventListener('touchstart', startDrawing)
    canvas.addEventListener('touchmove', draw)
    canvas.addEventListener('touchend', stopDrawing)
    canvas.addEventListener('wheel', handleZoom)
    canvas.addEventListener('touchmove', handlePan)

    return () => {
      canvas.removeEventListener('mousedown', startDrawing)
      canvas.removeEventListener('mousemove', draw)
      canvas.removeEventListener('mouseup', stopDrawing)
      canvas.removeEventListener('mouseout', stopDrawing)
      canvas.removeEventListener('touchstart', startDrawing)
      canvas.removeEventListener('touchmove', draw)
      canvas.removeEventListener('touchend', stopDrawing)
      canvas.removeEventListener('wheel', handleZoom)
      canvas.removeEventListener('touchmove', handlePan)
    }
  }, [isDrawing, scale, offset])

  const clearCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return
    const context = canvas.getContext('2d')
    if (!context) return
    context.clearRect(0, 0, canvas.width, canvas.height)
  }

  return (
    <Card id="whiteboard">
      <CardHeader>
        <CardTitle className="text-xl sm:text-2xl">Collaborative Whiteboard</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="w-full overflow-hidden">
          <canvas
            ref={canvasRef}
            width={400}
            height={300}
            className="border rounded mb-2 w-full touch-none"
            style={{
              transform: `scale(${scale}) translate(${offset.x}px, ${offset.y}px)`,
              transformOrigin: '0 0'
            }}
          />
        </div>
        <Button onClick={clearCanvas} className="w-full sm:w-auto">Clear Whiteboard</Button>
      </CardContent>
    </Card>
  )
}

